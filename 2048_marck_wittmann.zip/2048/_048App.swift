//
//  _048App.swift
//  2048
//
//  Created by Flavien Marck on 15/09/2023.
//

import SwiftUI

@main
struct _048App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
